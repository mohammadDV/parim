<?php
ini_set("display_errors",0);
require_once (dirname(__DIR__ ). "/vendor/autoload.php");
require_once (dirname(__DIR__ ). "/bootstarp/app.php");