<?php
return ["
TRUNCATE `departments`;
TRUNCATE `events`;
TRUNCATE `shifts`;
TRUNCATE `shift_department`;
"];