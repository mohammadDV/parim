<?php

new \System\Application\Application();

