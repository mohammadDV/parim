<?php

return [
    "DBHOST" => "127.0.0.1",
    "DBNAME" => "parim_db",
    "DBUSER" => "root",
    "DBPASS" => "",
];

