<?php


namespace App\Http\Controllers;

class Controller {


}