<?php

namespace App\Providers;

abstract class Provider{
    abstract public function boot();
}